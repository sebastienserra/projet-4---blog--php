<?php
$title="Modification des Articles";
$lien="../../";
require("../../includes/header.php");
require_once("../../includes/classes.php");
require("../../includes/menubackend.php");
require("../../models/backend/edit_model.php");
require("../../includes/footer.php");

