<?php
$title="Commentaires à modérer";
$lien="../../";
require("../../includes/header.php");
require("../../includes/menubackend.php");
require_once("../../includes/classes.php");
require("../../views/backend/reported_comments_view.php");
require("../../includes/footer.php");