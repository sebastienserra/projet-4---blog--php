<?php
$title="Article et commentaires associés";
$lien="../../";
require_once("../../includes/classes.php");
require("../../includes/header.php");
require("../../includes/menufrontend.php");
require("../../views/frontend/postandcomments_view.php");
require("../../includes/footer.php");


