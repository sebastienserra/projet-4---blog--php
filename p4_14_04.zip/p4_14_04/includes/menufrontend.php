<div id='#top'></div>
	<div id="nav_bar">
		<div class="navigation">
			<label for="hamburger"><span class="fas fa-bars"></span></label>
			<input type="checkbox" id="hamburger">
			<nav>
				<ul>
					<li><a href="<?php echo $lien;?>index.php">Accueil</a></li>
					<li><a href="<?php echo $lien;?>controllers/frontend/login_controller.php">Se connecter</a></li>
				</ul>
    		</nav>
    	</div>
    </div>