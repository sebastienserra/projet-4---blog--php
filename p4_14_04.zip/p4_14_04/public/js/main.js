//diaporama
diaporama.launchAuto();
diaporama.callRightClick();
diaporama.callLeftClick();
diaporama.callPause();
diaporama.rightArrowKeyboard();
diaporama.leftArrowKeyboard();
