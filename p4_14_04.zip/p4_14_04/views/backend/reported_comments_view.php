<div id="top"></div>
<?php
$displayReportedComments= new Crud;
echo $displayReportedComments->displayReportedComments();
?>