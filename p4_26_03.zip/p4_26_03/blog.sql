-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Gostitelj: 127.0.0.1:3306
-- Čas nastanka: 26. mar 2020 ob 08.43
-- Različica strežnika: 5.7.26
-- Različica PHP: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Zbirka podatkov: `blog`
--

-- --------------------------------------------------------

--
-- Struktura tabele `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_post` int(11) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `date_of_comment` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=latin1;

--
-- Odloži podatke za tabelo `comments`
--

INSERT INTO `comments` (`id`, `id_post`, `comment`, `date_of_comment`) VALUES
(1, 8, 'un bon commentaire', '2020-03-09 09:40:47'),
(2, 8, 'ah ca va mieux deja', '2020-03-09 09:40:47'),
(3, 22, 'ok', '2020-03-09 09:40:47'),
(5, 25, 'Le lorem ipsum c\'est barbant, mais bien utile.', '2020-03-09 09:40:47'),
(6, 25, 'J\'en rajoute encore', '2020-03-09 09:40:47'),
(7, 23, 'Le lorem ipsum...', '2020-03-09 09:40:47'),
(8, 24, 'Ces origines sont inconnues pour moi.', '2020-03-09 09:40:47'),
(9, 23, 'allez', '2020-03-09 09:40:47'),
(10, 23, 'allwe', '2020-03-09 09:40:47'),
(11, 23, 'le 23', '2020-03-09 09:40:47'),
(12, 23, 'envoyer le commentaire\r\n', '2020-03-09 09:40:47'),
(13, 23, 'envoyer le commentaire et voir\r\n', '2020-03-09 09:40:47'),
(65, 23, 'Testons les compliments encore une fois', '2020-03-17 18:42:26'),
(17, 23, 'encore un petit', '2020-03-09 09:40:47'),
(18, 23, '', '2020-03-09 09:40:47'),
(21, 23, 'que de compliments', '2020-03-09 09:40:47'),
(22, 28, 'Pagination reussie', '2020-03-09 09:40:47'),
(23, 29, 'super article', '2020-03-09 09:40:47'),
(24, 23, '', '2020-03-09 20:59:58'),
(25, 23, 'alors', '2020-03-09 21:00:47'),
(26, 23, 'un compliment', '2020-03-10 14:52:00'),
(27, 23, 'recommencons', '2020-03-10 14:53:55'),
(28, 23, 'moi aussi', '2020-03-10 15:04:44'),
(29, 23, 'que les compliments', '2020-03-10 15:07:29'),
(30, 23, 'que les compliments', '2020-03-10 15:09:32'),
(31, 23, 'que les compliments', '2020-03-10 15:09:36'),
(32, 23, 'Allez', '2020-03-10 15:16:57'),
(33, 23, 'Allez', '2020-03-10 15:20:07'),
(37, 25, 'un autre commentaire', '2020-03-11 08:00:53'),
(39, 25, 'nous sonnes le &amp;&amp;:&quot;', '2020-03-11 08:19:03'),
(64, 23, 'Testons les compliments', '2020-03-17 18:37:09'),
(42, 23, '&lt;script&gt;alert(\'hello\')&lt;/script&gt;;', '2020-03-11 17:04:22'),
(43, 23, 'envoyons un commentaire', '2020-03-13 15:34:04'),
(44, 25, 'Rajoutons un nouveau commentaire...', '2020-03-13 15:37:04'),
(45, 25, 'Rajoutons un nouveau commentaire...', '2020-03-13 15:37:55'),
(46, 25, 'Rajoutons un nouveau commentaire...', '2020-03-13 15:38:28'),
(47, 23, 'un commentaire pour la comm', '2020-03-13 21:44:38'),
(48, 23, 'let\'s do it again', '2020-03-13 21:46:30'),
(49, 23, 'of course', '2020-03-13 21:46:54'),
(50, 23, 'scratching my head...', '2020-03-13 21:48:17'),
(51, 23, 'scratching my head...', '2020-03-13 21:50:11'),
(52, 23, 'scratching my head...', '2020-03-13 21:50:45'),
(53, 23, 'scratching my head...', '2020-03-13 21:52:12'),
(54, 23, 'scratching my head...', '2020-03-13 21:52:47'),
(55, 23, 'scratching my head...', '2020-03-13 21:54:14'),
(56, 23, 'nouveau comm', '2020-03-13 21:55:47'),
(57, 23, 'nouveau comm', '2020-03-13 21:56:17'),
(58, 23, 'nouveau comm', '2020-03-13 21:56:36'),
(72, 23, 'Le lorem ipsum ca aide ', '2020-03-17 21:47:37'),
(61, 23, 'alllewwwe', '2020-03-14 15:24:55'),
(62, 23, 'alllewwwe', '2020-03-14 15:25:01'),
(63, 23, 'alllewwwe', '2020-03-14 15:25:08'),
(66, 23, 'allez encore une tentative...', '2020-03-17 18:44:12'),
(75, 23, '&lt;str?//', '2020-03-21 15:36:56'),
(68, 23, 'retentons', '2020-03-17 18:51:10'),
(69, 23, 'Ecrire un nouveau commentaire a moderer', '2020-03-17 21:31:46'),
(73, 38, 'drole de post', '2020-03-17 21:50:18'),
(71, 25, 'il faut moderer ce commentaire', '2020-03-17 21:32:37'),
(78, 1, 'voyons', '2020-03-25 11:13:39'),
(79, 1, 'alors', '2020-03-25 11:17:10'),
(80, 74, 'COMPLIMENTS ACCEPTES', '2020-03-25 12:42:09'),
(81, 74, 'PECCABLE', '2020-03-25 12:42:38'),
(91, 77, 'hi there', '2020-03-26 09:29:59'),
(84, 73, 'maintenan ca marche?', '2020-03-25 13:16:06'),
(93, 77, 'hi there', '2020-03-26 09:37:11'),
(86, 73, 'coolistik et coolistik', '2020-03-25 14:06:03'),
(87, 73, 'Mettons un commentaire', '2020-03-25 14:22:40'),
(94, 77, 'hi there', '2020-03-26 09:37:44'),
(89, 71, 'ecrivons un commentaire', '2020-03-25 20:44:10'),
(92, 77, 'hi there', '2020-03-26 09:30:59'),
(95, 77, 'ok', '2020-03-26 09:38:29'),
(96, 74, 'da', '2020-03-26 09:39:12'),
(97, 77, 'bien', '2020-03-26 09:39:40'),
(98, 77, 'bene', '2020-03-26 09:40:15'),
(99, 77, 'a posto', '2020-03-26 09:40:40');

-- --------------------------------------------------------

--
-- Struktura tabele `posts`
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `article` text NOT NULL,
  `creation_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=latin1;

--
-- Odloži podatke za tabelo `posts`
--

INSERT INTO `posts` (`id`, `article`, `creation_date`) VALUES
(64, '<h2 style=\"margin: 0px 0px 10px; padding: 0px; text-align: left; color: #000000; text-transform: none; line-height: 24px; text-indent: 0px; letter-spacing: normal; font-family: DauphinPlain; font-size: 24px; font-style: normal; font-weight: 400; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; background-color: #ffffff; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\">Qu\'est-ce que le Lorem Ipsum?</h2>\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; text-align: justify; color: #000000; text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; font-style: normal; font-weight: 400; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; background-color: #ffffff; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\">Le&nbsp;<strong style=\"margin: 0px; padding: 0px;\">Lorem Ipsum</strong>&nbsp;est simplement du faux texte employ&eacute; dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les ann&eacute;es 1500, quand un imprimeur anonyme assembla ensemble des morceaux de texte pour r&eacute;aliser un livre sp&eacute;cimen de polices de texte. Il n\'a pas fait que survivre cinq si&egrave;cles, mais s\'est aussi adapt&eacute; &agrave; la bureautique informatique, sans que son contenu n\'en soit modifi&eacute;. Il a &eacute;t&eacute; popularis&eacute; dans les ann&eacute;es 1960 gr&acirc;ce &agrave; la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus r&eacute;cemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.</p>', '2020-03-23 15:18:15'),
(71, '<p>Hellou</p>', '2020-03-23 15:56:39'),
(74, '<p>two more</p>', '2020-03-23 20:44:43'),
(73, '<p>coolistik</p>', '2020-03-23 16:17:38'),
(77, '<p>Hello worlde</p>', '2020-03-25 21:51:47'),
(66, '<h2 style=\"margin: 0px 0px 10px; padding: 0px; text-align: left; color: #000000; text-transform: none; line-height: 24px; text-indent: 0px; letter-spacing: normal; font-family: DauphinPlain; font-size: 24px; font-style: normal; font-weight: 400; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; background-color: #ffffff; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\">Pourquoi l\'utiliser?</h2>\r\n<p style=\"margin: 0px 0px 15px; padding: 0px; text-align: justify; color: #000000; text-transform: none; text-indent: 0px; letter-spacing: normal; font-family: \'Open Sans\', Arial, sans-serif; font-size: 14px; font-style: normal; font-weight: 400; word-spacing: 0px; white-space: normal; orphans: 2; widows: 2; background-color: #ffffff; font-variant-ligatures: normal; font-variant-caps: normal; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial;\">On sait depuis longtemps que travailler avec du texte lisible et contenant du sens est source de distractions, et emp&ecirc;che de se concentrer sur la mise en page elle-m&ecirc;me. L\'avantage du Lorem Ipsum sur un texte g&eacute;n&eacute;rique comme \'Du texte. Du texte. Du texte.\' est qu\'il poss&egrave;de une distribution de lettres plus ou moins normale, et en tout cas comparable avec celle du fran&ccedil;ais standard. De nombreuses suites logicielles de mise en page ou &eacute;diteurs de sites Web ont fait du Lorem Ipsum leur faux texte par d&eacute;faut, et une recherche pour \'Lorem Ipsum\' vous conduira vers de nombreux sites qui n\'en sont encore qu\'&agrave; leur phase de construction. Plusieurs versions sont apparues avec le temps, parfois par accident, souvent intentionnellement (histoire d\'y rajouter de petits clins d\'oeil, voire des phrases embarassantes).</p>', '2020-03-23 15:21:33');

-- --------------------------------------------------------

--
-- Struktura tabele `reported_comments`
--

DROP TABLE IF EXISTS `reported_comments`;
CREATE TABLE IF NOT EXISTS `reported_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_comment` int(11) NOT NULL,
  `date_of _reporting` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=43 DEFAULT CHARSET=latin1;

--
-- Odloži podatke za tabelo `reported_comments`
--

INSERT INTO `reported_comments` (`id`, `id_comment`, `date_of _reporting`) VALUES
(25, 72, '2020-03-17 21:48:28'),
(42, 83, '2020-03-26 08:59:46'),
(41, 83, '2020-03-26 08:59:13'),
(40, 90, '2020-03-26 08:58:40'),
(39, 90, '2020-03-26 08:58:36'),
(38, 90, '2020-03-26 08:48:04'),
(37, 90, '2020-03-25 21:53:02'),
(36, 88, '2020-03-25 21:50:08'),
(35, 88, '2020-03-25 21:49:18'),
(34, 88, '2020-03-25 21:48:56'),
(33, 88, '2020-03-25 21:48:35'),
(32, 88, '2020-03-25 21:47:41'),
(31, 85, '2020-03-25 21:47:30'),
(30, 85, '2020-03-25 21:46:21'),
(29, 82, '2020-03-25 21:33:27'),
(21, 69, '2020-03-17 21:32:49'),
(28, 89, '2020-03-25 20:44:29'),
(26, 73, '2020-03-17 21:50:33'),
(24, 71, '2020-03-17 21:33:27');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
