<?php
$title="Interface d'administration";
$lien="../../";
require("../../includes/header.php");
require("../../includes/menubackend.php");
require_once("../../includes/classes.php");
require("../../models/backend/backend_model.php");
require("../../views/backend/backend_view.php");
require("../../includes/footer.php");