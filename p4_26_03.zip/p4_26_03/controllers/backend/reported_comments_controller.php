<?php
$title="Modification des Articles";
$lien="../";
require("../../includes/header.php");
require_once("../../includes/classes.php");

require("../../views/backend/reported_comments_view.php");
require("../../includes/footer.php");