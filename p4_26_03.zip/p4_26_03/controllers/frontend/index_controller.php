<?php
require_once("./includes/classes.php");
require("./models/frontend/index_model.php");
require("./views/frontend/index_view.php");
