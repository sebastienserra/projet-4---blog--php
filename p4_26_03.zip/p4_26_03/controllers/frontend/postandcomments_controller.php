<?php
require_once("../../includes/classes.php");
require("../../models/frontend/postandcomments_model.php");
require("../../views/frontend/postandcomments_view.php");

