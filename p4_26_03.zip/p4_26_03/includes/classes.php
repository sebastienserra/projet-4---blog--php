<?php
class Crud{

	private $servername;
	private $username; 
	private $password; 
	private $dbname;
	private $charser;  


	public function connect(){
		$this -> servername = "localhost";
		$this -> username = "root";
		$this -> password = "";
		$this -> dbname = "blog";
		$this -> charset = "utf8mb4";

		try {
				$dsn = "mysql:host=".$this->servername.";dbname=".$this->dbname.";charset=".$this->charset;
				$db = new PDO($dsn,$this -> username, $this -> password);
				$db -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
				return $db;


			} catch (PDOException $e) {
				echo "Connection failed: ".$e->getMessage();
		}
			
    }
    public function saveRecords(){
	$req = $this->connect()->prepare("INSERT INTO posts(article) values(?)");
	$req->execute(array(($_POST['article'])));
	}
	public function getAllData(){

		$req = $this->connect()->query("SELECT * FROM posts ORDER BY id DESC LIMIT 0,2");
		?>
		<table border=1>
		<?php
			while($row= $req->fetch(PDO::FETCH_ASSOC)) {
		?>		
   			<div class="present"><p><?php echo $row['article'];?></p>
   			<p>
   			<a href="backend_controller.php?delete=<?php echo $row['id'];?>"class="btn btn-primary btn-sm" id="confirmation"><span class="fas fa-trash-alt"></span></a>
   			<a href="edit_controller.php?edit=<?php echo $row['id'];?>" class="btn btn-primary btn-sm"><span class="fas fa-edit"></span></a>
   			</p>
			</div>
		<?php
		}

	}
	/*public function CountRows(){
		$req = $this->connect()->query('SELECT COUNT(*) AS nb_posts FROM posts');
		$donnees = $reponse->fetch();
		$nb_posts=$donnees['nb_posts'];
	}*/
	public function destroy($id){
		$rep = $this->connect()->prepare("DELETE FROM posts WHERE id=:id");
		$rep->execute(['id'=>$id]);
		return $rep;
	}
	public function eraseReportedComment($id){
		$rep = $this->connect()->prepare("DELETE FROM comments WHERE id=:id");
		$rep->execute(['id'=>$id]);
		return $rep;
	}

	//display reported comments
	public function displayReportedComments(){
		$report = $this->connect()->query('SELECT comments.id, comments.comment, comments.id_post, reported_comments.id_comment 
	FROM comments 
	JOIN reported_comments
	ON comments.id = reported_comments.id_comment
	');
		while ($donnees = $report->fetch()){
	?>
		<div class="present"> 
		<p><?php echo $donnees['comment'] ?></p> 
		<a href="backend_controller.php?moderate=<?php echo $donnees['id_comment'] ?>" class="btn btn-primary btn-sm"><span class="fas fa-trash-alt"></span></a>
		</div>
	<?php

		}
	}
}


class Edit extends Crud{
	public function onePost($id){
		$req = $this->connect()->prepare("SELECT article, id FROM posts WHERE id=:id");
		$req->execute(['id'=>$id]);
		$result=$req->fetch(PDO::FETCH_ASSOC);
		return $result['article'];
	}

	public function update(){
		if(isset($_POST['update'])) {
			$article=$_POST['article'];
			$id=$_POST['id'];
			$req = $this->connect()->prepare("UPDATE posts SET article=:article,id=:id WHERE id=:id");
			$result= $req->execute(array(":article"=>$article, ":id"=>$id));
			header("location: backend_controller.php");
		}	
	}	
}



class Front extends Crud{
	public function saveComment(){

	// Insertion du message à l'aide d'une requête préparée
	$req = $this->connect()->prepare("INSERT INTO comments(comment, id_post) values(?,?)");
	$req->execute(array(($_POST['comment']), ($_POST['id_post'])));
	header("location: ../../index.php");
	}

	public function displayPosts(){
	$req = $this->connect()->query("SELECT * FROM posts ORDER BY id DESC LIMIT 0,2");
			while($row= $req->fetch(PDO::FETCH_ASSOC)) {
		?>		
   			<div class="present"><p><?php echo $row['article'];?></p>
   			<p>
   			<a href="views/frontend/form_comments_view.php?comment=<?php echo $row['id'];?>" class="btn btn-primary btn-sm"><span class="fas fa-comment"></span></a>
   			<a href="controllers/frontend/postandcomments_controller.php?postandcomments=<?php echo $row['id'];?>" class="btn btn-primary btn-sm"><span class="fas fa-comments"></span></a>
   			</p>
			</div>
		<?php
		}
	}
	public function getPost(){
	// Retrieve article by id
		$req = $this->connect()->prepare("SELECT id,article FROM posts WHERE id = ?");
		$req->execute(array($_GET['postandcomments']));
		$donnees = $req->fetch();
		?>
		<div class="present">
   		 <p><?php echo (($donnees[1])); ?></p>
   		</div>
		<?php
	}
	
	public function getComments(){
			// Retrieve comments
		$comments = $this->connect()->prepare("SELECT comment, id FROM comments WHERE id_post = ? ORDER BY date_of_comment DESC LIMIT 0,4");
		$comments->execute(array($_GET['postandcomments']));
		while ($donnees = $comments->fetch(PDO::FETCH_ASSOC))
		{
		?>
		<div class="present">
   			 <p><?php echo (($donnees['comment'])); ?></p>
    		<p><a href="../../views/frontend/resultat_report.php?report=<?php echo $donnees['id'] ?>" name="report", id="report" class="btn btn-primary btn-sm"><span class="fas fa-comment-slash"></span></a></p>
		</div>
		<?php
		}
	}
	function getReportedComment(){
		// Récupération des commentaires
		$req = $this->connect()->prepare("INSERT INTO reported_comments(id_comment) VALUES(?)");
		$req->execute(array(htmlspecialchars($_GET['report'])));
	}

}


