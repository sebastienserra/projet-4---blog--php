<div id='#top'></div>
	<div id="barre_nav">
<!-- 		<div id="logo">
		<a href="#top"><img src="../codesmile/pictures/logo.png" alt="logo"></a>
		</div> -->
		<div class="navigation">
			<label for="hamburger">&#9776;</label>
			<input type="checkbox" id="hamburger">
			<nav>
				<ul>
					<li><a href="../../controllers/backend/backend_controller.php">Admin</a></li>
					<li><a href="../../controllers/backend/reported_comments_controller.php">Moderation</a></li>
					<li><a href="../../index.php">Blog</a></li>
				</ul>
    		</nav>
    	</div>
    </div>