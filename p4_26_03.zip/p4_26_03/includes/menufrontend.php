<div id='#top'></div>
	<div id="barre_nav">
<!-- 		<div id="logo">
		<a href="#top"><img src="../codesmile/pictures/logo.png" alt="logo"></a>
		</div> -->
		<div class="navigation">
			<label for="hamburger">&#9776;</label>
			<input type="checkbox" id="hamburger">
			<nav>
				<ul>
					<li><a href="<?php echo $lien;?>index.php">Blog</a></li>
					<li><a href="<?php echo $lien;?>controllers/backend/backend_controller.php">Backend</a></li>
				</ul>
    		</nav>
    	</div>
    </div>