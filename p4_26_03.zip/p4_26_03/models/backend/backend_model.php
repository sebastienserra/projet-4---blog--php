<?php
require_once("../../includes/classes.php");


if (isset($_POST['bouton_form'])){
	
	$article=$_POST['article'];

$object = new Crud;
echo $object-> saveRecords($article);

}

if(isset($_GET['delete'])){

	$id=$_GET['delete'];

	$erase = new Crud;
	$erase->destroy($id);

}

if(isset($_GET['moderate'])) {
	$id=$_GET['moderate'];
	$eraseReportedComment = new Crud;
	$eraseReportedComment->eraseReportedComment($id);	
}
