<?php 
if(isset($_GET['edit'])) {
	$id=$_GET['edit'];
	require("../../views/backend/edit_view.php");
}
