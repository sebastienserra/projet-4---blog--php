//diaporama
diaporama.lancementAuto();
diaporama.appelClicDroit();
diaporama.appelClicGauche();
diaporama.appelPause();
diaporama.flecheDroiteClavier();
diaporama.flecheGaucheClavier();
