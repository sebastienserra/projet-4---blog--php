<div id="top"></div>
<?php 


$objet = new Crud;
$objet->getAllData();
?>
<div class="id_commentaire"> Id commentaires signalés: </div>
<div class="id_commentaire"><span> <a href="../../controllers/backend/reported_comments_controller.php">Modérer les commentaires</a><span>
</div>
<form action="" method="post">
	<p><textarea name="article" id="article"  rows="10" cols="50" maxlength="250" placeholder="Ecrire ici."></textarea></p>
	
	<p><input class="btn btn-primary" name="bouton_form" id="bouton_form" type="submit" value="Envoi"></p>
</form>