
<form action="", method="post">
	<p><input type="hidden" name="id" id="id" value="<?php echo $_GET['edit']; ?>"></p>
<!-- 	Name: <p><input type="text" name="nm" value="<?php echo $objet['name']; ?>"></p> -->
	<p><textarea name="article" id="article"  rows="10" cols="50" maxlength="250"><?php 
$edit = new Edit; echo $edit->onePost($id); ?></textarea></p>
	<input class="btn btn-primary" type="submit" name="update" value="Update">
</form>
<?php


	$mis = new Edit;
	echo $mis->update();
?>