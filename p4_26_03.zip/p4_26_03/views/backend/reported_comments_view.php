<div id="top"></div>
<?php
$title="Commentaires à modérer";
$lien="../../";
require("../../includes/header.php");
require("../../includes/menubackend.php");
require_once("../../includes/classes.php");
require("../../includes/footer.php");
$displayReportedComments= new Crud;
echo $displayReportedComments->displayReportedComments();
?>