<?php 
$title="Accueil";
$lien="../../";
require_once("../../includes/classes.php");
require("../../includes/header.php");
require("../../includes/menufrontend.php");
require("../../includes/footer.php");
?>
<div id="top"></div>
<form action="" method="post">
	<div class="form-group">
	<p><input type="text" name="id_post" value="<?php echo $_GET['comment']; ?>" class="form-control"></p>
	</div>
	<div class="form-group">
	<p><label>Votre commentaire:</label>
		<textarea name="comment" id="comment" class="form-control" rows="3" cols="50" maxlength="250" placeholder="Nous n'acceptons que les compliments ;-)"></textarea>
	</p>
	</div>
	<p><input class="btn btn-primary" name="bouton_comment" id="bouton_comment"type="submit" value="Envoi"></p>
</form>
<?php


if (isset($_POST['id_post']) AND isset($_POST['comment']))
	{
		$zu= new Front;
		$zu->savecomment();

	}
	

?>