<?php
$title="Accueil";
$lien="./";
require("./includes/header.php");
require("./includes/menufrontend.php");

?>
<div id="top"></div>
<div class="container">
    <div class="row">
      <div class="col-lg">
        <div id="container">
          <div class="demi_cercle">
            <div class="demi_cercle_gauche">
              <div class="flechegauche">
              </div> 
            </div>
          </div>
        <div>
          <img id="diapo" src="./public/images/alaska_img1.jpg" alt="diaporama">
        </div>
        <div class="demi_cercle">
          <div class="demi_cercle_droite">
            <div class="flechedroite">
            </div>
          </div>
        </div>
      </div>
      <div id="contient_pause">
        <div class="push" id="btn_pause">
        </div>
      </div>
      <div id="contient_play">
        <div class="push" id="btn_play">
        </div>
      </div>
      <div id="texte_diaporama">
      </div>
    </div>
  </div>
</div>



<?php
$display= new Front; 
echo $display->displayPosts(); 

require("./includes/footer.php");
?>