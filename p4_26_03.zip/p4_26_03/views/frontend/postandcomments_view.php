<?php 
$title="Article et commentaires associés";
$lien="../../";
require_once("../../includes/classes.php");
require("../../includes/header.php");
require("../../includes/menufrontend.php");
require("../../includes/footer.php");
?>
<div id="top"></div>
<h2>Article</h2>
<?php
$post= new Front; 
echo $post->getPost();
?>
<h2>Commentaires associés</h2>
<?php
$comments= new Front; 
echo $comments->getComments();

?>