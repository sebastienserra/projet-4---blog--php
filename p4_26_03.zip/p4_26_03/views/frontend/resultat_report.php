<div id="top"></div>
<?php
$title="Accueil";
$lien="../../";
require_once("../../includes/classes.php");
require("../../includes/header.php");
require("../../includes/menufrontend.php");
require("../../includes/footer.php");
if (isset($_GET['report'])){
	$report=$_GET['report'];
	echo$report;
$reportComment = new Front;
$reportComment->getReportedComment();
echo '<div class="success">Commentaire signalé avec succès!</div>';
} 
?>